-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 07, 2022 at 02:08 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `temp`
--

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `rollno` int(11) NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `emailID` varchar(20) DEFAULT NULL,
  `contact` varchar(12) DEFAULT NULL,
  `gender` char(1) DEFAULT NULL,
  `address` varchar(30) DEFAULT NULL,
  `pincode` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`rollno`, `name`, `emailID`, `contact`, `gender`, `address`, `pincode`) VALUES
(1, 'Bansri', 'bansrithakkar0@gmail', '9890000000', 'F', 'jadeshwar society ', 363310),
(2, 'ashwini', 'ashwinipatil0@gmail.', '8888888888', 'F', 'devpur road ', 424002),
(3, 'uttamshlok', 'uttamshlok0@gmail.co', '7040602080', 'M', 'Mithakhali navranpura', 380009),
(4, 'shane', 'shanedavid0@gmail.co', '1205909783', 'M', 'Shane colony ', 25008),
(5, 'Jayashri', 'jayashreepatil0@gmai', '7586528632', 'F', 'kazi nagar', 425405);

-- --------------------------------------------------------

--
-- Table structure for table `student_address`
--

CREATE TABLE `student_address` (
  `student_pincode` int(11) DEFAULT NULL,
  `student_city` varchar(30) DEFAULT NULL,
  `student_state` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_address`
--

INSERT INTO `student_address` (`student_pincode`, `student_city`, `student_state`) VALUES
(363310, 'Surendranagar', 'Gujarat'),
(424002, 'dhule', 'Maharashtra'),
(380009, 'Ahmedabad', 'Gujarat'),
(25008, 'New Jersey', 'United States of Ame'),
(425405, 'shirpur', 'Maharashtra');

-- --------------------------------------------------------

--
-- Table structure for table `student_subject`
--

CREATE TABLE `student_subject` (
  `subject_id` int(11) DEFAULT NULL,
  `subject_name` varchar(20) DEFAULT NULL,
  `marks` int(11) DEFAULT NULL,
  `subject_status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`rollno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `rollno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
